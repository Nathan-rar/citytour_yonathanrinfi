package com.example.yonathanrinfi_city_tour;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
