import 'package:flutter/material.dart';
import 'package:yonathanrinfi_city_tour/main.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
            )
          ],
        )

        );
  }
}

